$(document).ready(function() {
    $(".navbar_extra_footer").html(""); // clear extra footer
    $("a.reference.external").attr("target", "_blank"); // external links open in a new tab
});