# Installation

Installing Reaktoro for Python and C++ can be done in different ways, from
executing a simple terminal command to building the entire project from
source.

All current possibilities are detailed in the next sections.
