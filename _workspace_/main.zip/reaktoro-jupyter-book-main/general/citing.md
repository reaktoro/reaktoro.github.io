# Citing

If you want to cite Reaktoro in your publication, please use the following
citation:

 * Leal, A.M.M. (2015). *Reaktoro: An open-source unified framework for modeling chemically reactive systems*. https://reaktoro.org
