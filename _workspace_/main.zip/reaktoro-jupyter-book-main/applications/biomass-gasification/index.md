# Biomass Gasification

This section presents Reaktoro's capabilities for modeling biomass gasification.

```{tableofcontents}
```
