# Geobiology

This section presents capabilities of Reaktoro for geobiological modeling.

```{tableofcontents}
```
